<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>Resource not found - NetCoreCMS Admin - 172.70.92.218 - </title>
    <link rel="shortcut icon" href="/media/Images/Unmesh/favicon2.png" type="image/x-icon">
    <link rel="icon" href="/media/Images/Unmesh/favicon2.png" type="image/x-icon">
<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css" />
<!-- MetisMenu CSS -->
<link rel="stylesheet" href="/css/metisMenu.min.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="/css/sb-admin-2.min.css">
<!-- Custom Fonts -->
<link rel="stylesheet" type="text/css" href="/lib/font-awesome/css/font-awesome.min.css">

<link href="/lib/css-loader/dist/css-loader.css" rel="stylesheet" />
<!-- Custom CSS -->

<!-- jQuery -->
<script src="/lib/jquery/jquery.min.js"></script>
<script src="/lib/jquery-serializeObject/jquery.serializeObject.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="/lib/bootstrap/js/bootstrap.min.js"></script>

<link href="/css/ncc-common.css" rel="stylesheet" />
<script src="/lib/notifyjs/notify.min.js"></script>
<script src="/js/ncc-common.js?v=T0H2TFAR9N7lavo6ks_KYUAx0vWR-INfAUWMqVE_g5o"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- View: /Views/Shared/AdminParts/_Head.cshtml-->
<meta name="generator" content="NetCoreCMS v1.0.0.6" />

    
</head>

<body>
    <!-- Message Show -->
    <div class="col-md-12">
        <div id="messageContainer">
                                            </div>
    </div>

    <!-- Begin page content -->
    <div class="container" style="height:90vh">
        <link href='//fonts.googleapis.com/css?family=Satisfy' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>

<style type="text/css">
    

    body {
        /*background: #f3f3e1;*/
    }

    .error {
        font-family: 'Monda', cursive;
        /*margin-top: 50px;*/
        text-align: center;
    }
        .error h1 {
            font-size: 200px;
            color: #8F8E8C;
            text-align: center;
            margin-bottom: 1px;
            text-shadow: 5px 5px 10px #888;
        }
        .error h3 {
            font-family: 'Satisfy', cursive;
            color: #8F8E8C;
            text-align: left;
            margin-bottom: 1px;
        }
</style>

<div class="error" style="padding-top:20vh;">
    <h1>404</h1>
    <div class="sub">
        <p><a class="btn btn-primary" href="/">Back to Home</a></p>
    </div>
    <hr />
    <div>
        <div style="margin-left:30%; margin-right:auto;">
            <h3> </h3>
            <h3> </h3>
        </div>
    </div>
    <hr />
</div>
    </div>


    

<div class="row text-center">
    <hr />
    <footer>
        <p class="text-muted text-center">Developed by <a title="OnnoRokom Software Ltd." target="_blank" href="https://onnorokomsoftware.com">OnnoRokom Software Ltd.</a> v<span>1.0.0.6</span>. PID: 3236</p>

    </footer>
</div>
<!-- /#wrapper -->
<!-- Metis Menu Plugin JavaScript -->
<script src="/js/metisMenu.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="/js/sb-admin-2.min.js"></script>

<!--Bootstrap DateTime Picker Start-->
<script src="/lib/moment/moment.js"></script>
<link href="/lib/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
<script src="/lib/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
    $(function () {
        $('.datetimepicker').datetimepicker({
            format: 'MMM D, YYYY hh:mm A'
        });
    });
</script>
<!--Bootstrap DateTime Picker END-->
<script>
        $(document).ready(function () {
            $.notify.defaults({
                "globalPosition": "top center"
            });

            var isMenuActive = false;
            $('.sidebar-nav').find('a').each(function () {
                if ($(this).hasClass('active')) {
                    isMenuActive = true;
                }
                //console.log($(this).attr('href'));
                //console.log(pathname);
                //console.log(pathnameLang);
                //console.log(pathname);
            });

            if (isMenuActive == false) {
                var pathname = decodeURI(window.location.pathname);
                if (pathname == "/Dashboard" || pathname == "/bn/Dashboard") {
                    $('.sidebar-nav').find('a').each(function () {
                        if ($(this).attr('href') == "/Dashboard/Index" || $(this).attr('href') == "/bn/Dashboard/Index") {
                            //$(this).parent("li").parent("ul").addClass('active collapse in');
                            $(this).addClass('active');
                            isMenuActive = true;
                            console.log($(this).attr('href'));
                        }
                    });
                }
            }

            //console.log(isMenuActive);
            if (isMenuActive == false) {
                $('.sidebar-nav').find('a').each(function () {
                    if ($(this).attr('href') == "/CmsTheme/Settings" || $(this).attr('href') == "/bn/CmsTheme/Settings") {
                        $(this).parent("li").parent("ul").addClass('active collapse in');
                        $(this).addClass('active');
                    }
                });
            }

            //Show hide left menu
            $("#show-hide-left-menu").click(function () {
                //console.log("sh: In");
                //console.log($('.sidebar:visible').length);
                if ($('.sidebar:visible').length == 0) {
                    $(".sidebar").show();
                    $("body").css("maxWidth", "");
                    $("#page-wrapper").css("margin-left", "");
                }
                else {
                    $(".sidebar").hide();
                    $("body").css("maxWidth", "99%");
                    $(".navbar").css("maxWidth", "98%");

                    $("#page-wrapper").css("margin-left", "10px");
                }
            });
        });
</script>

	<iframe id="AnalyticsIFrame" src="" style="height:1px; width:1px; border: none;"></iframe>
	<script type="text/javascript" src="https://onnorokomprojukti.com/lib/m2-analytics.js"></script>



<!-- View: /Views/Shared/AdminParts/_Footer.cshtml-->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZES523VP5K"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZES523VP5K');
</script>

;
    

</body>
</html>


